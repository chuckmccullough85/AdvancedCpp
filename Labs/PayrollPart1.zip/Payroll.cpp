#include <iostream>
#include "Organization.h"
#include "Employee.h"

using namespace std;
using namespace payroll;

int main()
{

}

