#include "HumanResource.h"
#include "Employee.h"
#include "Factory.h"

namespace payroll {

}