#include "HourlyEmployee.h"
#include "Factory.h"

namespace payroll {

}