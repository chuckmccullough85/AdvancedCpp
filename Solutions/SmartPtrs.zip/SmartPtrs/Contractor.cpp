#include <string>
#include "Contractor.h"
#include "Factory.h"

namespace payroll {

}