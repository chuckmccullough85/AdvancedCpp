#pragma once
#include <string>
#include <list>
#include "Payable.h"


namespace payroll {
    inline double payOne(double total, Payable* employee) 
    {
        return total + employee->pay();
    }


    class Organization
    {
    public:
        Organization() = default;
        Organization(std::string name) : name(name) {}

        void setName(std::string name) { this->name = name; }
        std::string getName() const { return name; }
        void addEmployee(Payable* employee) { employees.push_back(employee); }
        std::list<Payable*> getEmployees() const { return employees; }

        double pay() const
        {
            double totalPay = 0;
            for (auto employee : employees)
            {
                totalPay += employee->pay();
            }
            return totalPay;
        }
    private:

        std::string name;
        std::list<Payable*> employees;
    };        
    
 }

