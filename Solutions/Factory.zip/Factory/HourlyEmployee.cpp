#include <string>
#include "HourlyEmployee.h"
#include "Factory.h"

using namespace std;
namespace payroll {
    //bool HourlyEmployee::m_registered = factory::ObjectFactory<HumanResource*>::Instance()
    //    .Register("H"s, makeResource<HourlyEmployee, HumanResource>);

}