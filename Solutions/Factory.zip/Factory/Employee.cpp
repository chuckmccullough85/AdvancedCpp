#include <string>
#include "HumanResource.h"
#include "Employee.h"
#include "Factory.h"
using namespace std;

namespace payroll {

}